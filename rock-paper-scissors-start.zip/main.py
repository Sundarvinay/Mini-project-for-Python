import random
rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
l = [rock,paper,scissors]
kee = random.seed()
print(f"rock : {l[0]} \n paper : {l[1]} \n scissors : {l[2]}")
userchoice = int(input("Enter your choice \n1. Rock \n2. Paper \n3.scissors\n"))-1

computer = random.randint(0,2)
print (f"Computer : \n{l[userchoice]}")
print (f"Computer : \n{l[computer]}")
if userchoice == computer:
  print("match draw")
elif userchoice==0 and computer==2:
   print ("You win")
elif userchoice==1 and computer==0:
   print ("You win")
elif userchoice==2 and computer==1:
   print ("You win")
else:
  print ("Computer win")

